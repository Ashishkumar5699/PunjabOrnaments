﻿namespace PunjabOrnaments.CustomViews
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
