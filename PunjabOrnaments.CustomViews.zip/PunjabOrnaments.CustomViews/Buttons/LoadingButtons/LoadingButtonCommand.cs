﻿namespace PunjabOrnaments.CustomViews.Buttons.LoadingButton
{
    public class LoadingButtonCommand
    {
    }
}
