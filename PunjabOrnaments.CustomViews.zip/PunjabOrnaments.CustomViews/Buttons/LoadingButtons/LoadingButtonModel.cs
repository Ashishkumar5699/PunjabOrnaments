﻿using System.Windows.Input;

namespace PunjabOrnaments.CustomViews.Buttons.LoadingButton
{
    public class LoadingButtonModel
    {
        public bool IsLoading { get; set; }
        public Command Command { get; set; }
    }
}
